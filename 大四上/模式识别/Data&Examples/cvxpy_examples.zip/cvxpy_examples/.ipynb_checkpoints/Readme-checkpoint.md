# The files in this folder include a few examples using CVXPY to solve convex optimization
* 