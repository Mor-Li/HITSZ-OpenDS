# The files in this folder include a few examples using CVXPY to solve convex optimization.
* CVXPY is an open source Python-embedded modeling language for convex optimization problems. 
* It lets you express your problem in a natural way that follows the math, rather than in the restrictive standard form required by solvers.
* Website of the package: https://www.cvxpy.org/index.html
* More examples in: https://www.cvxpy.org/examples/
