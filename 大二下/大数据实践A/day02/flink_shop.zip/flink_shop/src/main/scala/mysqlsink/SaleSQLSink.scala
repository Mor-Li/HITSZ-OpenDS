package mysqlsink
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction
import java.sql._
import objectclass.StringAndDouble
/***
 * 开发1
 * @param table
 */
class SaleSQLSink(table:String) extends RichSinkFunction[StringAndDouble] with Serializable {
  //定义连接的MYSQL配置参数
  var conn:Connection=_
  var ps:PreparedStatement=_
  val user="root"
  val password="123456"
  val driver="com.mysql.jdbc.Driver"
  val url="jdbc:mysql://master:3306/fk_shop"
  override def invoke(value: StringAndDouble): Unit = {
    Class.forName(driver)
    conn = DriverManager.getConnection(url,user,password)
    val sql="insert into "+table+" values(?,?)"
    ps = conn.prepareStatement(sql)
    ps.setString(1,value.getDate())
    ps.setDouble(2,value.getSale())
    ps.executeUpdate()
    if(ps!=null) ps.close()
    if(conn!=null) conn.close()
  }
}
