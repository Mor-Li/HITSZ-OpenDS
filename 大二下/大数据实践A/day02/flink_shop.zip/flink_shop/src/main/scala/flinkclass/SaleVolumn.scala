package flinkclass
import java.util.Properties
import mysqlsink.SaleSQLSink
import objectclass.StringAndDouble
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.scala._
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer
import org.apache.flink.api.common.serialization.SimpleStringSchema

/***
 *01 统计每日的销售额、统计每日点击流
 */
object SaleVolumn {
  def main(args: Array[String]): Unit = {
    //初始化环境变量
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    //配置Kafka参数
    val pro = new Properties()
    //kafak的代理
    pro.setProperty("bootstrap.servers","master:9092,slave1:9092,slave2:9092")
    //kafka 组ID
    pro.setProperty("group.id","test")
    //创建数据源
    val stream  = env.addSource(new FlinkKafkaConsumer[String]("shop",new SimpleStringSchema(),pro))
    //数据处理过程
    //id0         用户名1,年龄2,性别3,商品id4,价格5,  门店id6,购买行为7,手机号8,邮箱9,       购买时间10
    //471655345890,Vpxwe,44,woman,650012,538.29,313019,fav,13516482705,YUvRxnSWcO@gmail.com,2019-08-04
    val data = stream.map(x=>x.split(",")).filter(x=>x.nonEmpty && x.length==11)
      .map{x=>if(x(7).contains("buy")) (x(x.length-1),(x(5).toDouble,1.0)) else (x(x.length-1),(0.0,1.0))}
      .keyBy(0).timeWindow(Time.minutes(1))  //timeWindow 设置时间1分钟执行一次
      .reduce((x,y)=>(x._1,(x._2._1+y._2._1,x._2._2+y._2._2)))
    //(2022-12-1,(100,1),(0.0,1))
    //保存每日销售额到MYSQL表
    data.map(x=>new StringAndDouble(x._1,x._2._1)).addSink(new SaleSQLSink("salevolume"))
    //保存每日点击流到mysql表
    data.map(x=>new StringAndDouble(x._1,x._2._2)).addSink(new SaleSQLSink("visitcount_everyday"))
    env.execute()
  }
}
