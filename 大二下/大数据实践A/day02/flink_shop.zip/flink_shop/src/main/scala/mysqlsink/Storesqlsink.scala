package mysqlsink
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction
import objectclass.date_store_sale
import java.sql._

class Storesqlsink(table:String) extends RichSinkFunction[date_store_sale] with Serializable {
  var conn:Connection=_
  var ps:PreparedStatement=_
  val user="root"
  val password="123456"
  val driver="com.mysql.jdbc.Driver"
  val url="jdbc:mysql://192.168.10.102:3306/fk_shop"
  override def invoke(value: date_store_sale): Unit = {
    Class.forName(driver)
    conn=DriverManager.getConnection(url,user,password)
    val sql="insert into "+table+" values(?,?,?)"
    ps=conn.prepareStatement(sql)
    ps.setString(1,value.getDate())
    ps.setString(2,value.getStore())
    ps.setDouble(3,value.getSale())
    ps.executeUpdate()
    if(ps!=null) ps.close()
    if(conn!=null) conn.close()
  }
}
