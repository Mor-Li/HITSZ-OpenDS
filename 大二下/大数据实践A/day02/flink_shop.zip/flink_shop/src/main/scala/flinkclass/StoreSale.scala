package flinkclass

import java.util.Properties

import mysqlsink.{SaleSQLSink, Storesqlsink}
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.scala._
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer
import org.apache.flink.api.common.serialization.SimpleStringSchema
import objectclass.date_store_sale

/**
 * 开发2 统计每日每家门店总销售额
 */
object StoreSale {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    //kafka集群参数配置
    val pro = new Properties()
    pro.setProperty("bootstrap.servers","node1:9092")
    pro.setProperty("group.id","test")
    //创建源
    val stream = env.addSource(new FlinkKafkaConsumer[String]("shop",new SimpleStringSchema(),pro))
    //数据转换
    //id0,用户名1,年龄2,性别3,商品id4,价格5,  门店id6,购买行为7,手机号8,邮箱9,       购买时间10
    //471655345890,Vpxwe,44,woman,650012,538.29,313019,fav,13516482705,YUvRxnSWcO@gmail.com,2019-08-04
    val data=stream.map(x=>x.split(",")).
      filter(x=>x.nonEmpty && x.length==11 && x(7).contains("buy"))
      .map(x=>((x(x.length-1),x(6)),x(5).toDouble))
      .keyBy(0).timeWindow(Time.minutes(1))
      .sum(1).map(x=>new date_store_sale(x._1._1,x._1._2,x._2))

    //数据存储
    data.addSink(new Storesqlsink("store_sale"))
    env.execute()
  }
}