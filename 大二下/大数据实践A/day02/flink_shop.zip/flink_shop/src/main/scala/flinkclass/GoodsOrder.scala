package flinkclass
import java.util.Properties
import objectclass.StringAndDouble
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.scala._
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer
import org.apache.flink.api.common.serialization.SimpleStringSchema
import org.apache.flink.streaming.api.windowing.windows.TimeWindow
import org.apache.flink.streaming.api.scala.function.ProcessWindowFunction
import org.apache.flink.util.Collector

/**
 * 开发3 商品销量实时统计,并选出10大热销商品
 */
object GoodsOrder {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    //kafka集群参数配置
    val pro = new Properties()
    pro.setProperty("bootstrap.servers","node1:9092")
    pro.setProperty("group.id","test")
    //创建源
    val stream = env.addSource(new FlinkKafkaConsumer[String]("shop",new SimpleStringSchema(),pro))
    //数据转换
    // ProcessWindowFunction[In,Out,Key,Window]
    val data=stream.map(x=>x.split(",")).filter(x=>x.nonEmpty && x.length==11 && x(7)
      .contains("buy")).map(x=>new StringAndDouble(x(4),1.0))
      .keyBy(x=>x.getDate()).timeWindow(Time.minutes(1))
      .process(new ProcessWindowFunction[StringAndDouble,String,String,TimeWindow]{
        override def process(key: String, context: Context, elements: Iterable[StringAndDouble], out: Collector[String]): Unit = {
          val getsum = elements.toList.groupBy(x=>x.getDate()).map{tmp=>val ll=tmp._2.map(x=>x.getSale()).sum;(tmp._1,ll)}
          val e = getsum.toList.sortBy(x=>x._2).reverse.take(10)
          e.map(x=>out.collect(System.currentTimeMillis().toString()+":"+x._1+":"+x._2))
        }
      })
    //数据存储
    data.print()
    env.execute()
  }
}
