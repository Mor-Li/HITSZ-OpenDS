package objectclass

class StringAndDouble(datetime:String,sale:Double) {
  def getDate()={datetime}
  def getSale()={sale}
}
