## Data extracted from library(Countr)
load("../data/football.rda")

## EPL score data (2009 - 2016)
str(football)

## Fit to a univariate Poisson:
library(vcd)
hTG.fit <- goodfit(football$homeTeamGoals, type="poisson")
hTG.fit$par

plot(hTG.fit)

## Fit to a univariate Poisson, v2:
library(fitdistrplus)
hTG.fit.v2 <- fitdist(football$homeTeamGoals, "pois")
hTG.fit.v2

## Fit to a univariate Poisson, v3:

FB.pois0 <- glm(homeTeamGoals ~ 1, 
                data=football, family="poisson")

FB.pois0$coefficients

exp( unname(FB.pois0$coefficients) )

## Focus on season 2009-2010:
EPL09 <- subset(football, seasonId==2009, 
                select=-c(seasonId, gameDate))

EPL09$homeTeam <- factor(EPL09$homeTeam)
EPL09$awayTeam <- factor(EPL09$awayTeam)

str(EPL09)

## All teams:
unique(EPL09$homeTeam)

## Summary of data:
home.goals <- EPL09$homeTeamGoals
away.goals <- EPL09$awayTeamGoals

summary(home.goals)
summary(away.goals)

par(mfrow=c(1,2), pty="s")

barplot(table(home.goals))
barplot(table(away.goals))

## Fit EPL09 to two models:
EPL09.pois0 <- glm(homeTeamGoals ~ 1, 
                   data=EPL09, family="poisson")

EPL09.pois1 <- glm(homeTeamGoals ~ homeTeam + awayTeam, 
                   data=EPL09, family="poisson")

## Model comparison:
library(vcdExtra)
LRstats(EPL09.pois0, EPL09.pois1)

anova(EPL09.pois0, EPL09.pois1, test="LR")

summary(EPL09.pois1)

## Basic diagnostic:
par(mfrow=c(2,2), cex=1, pty="s")
plot(EPL09.pois1, which=c(1,2,4,5))

## Compare prediction to observation:
par(cex=1.5, pch=19)
plot(predict(EPL09.pois1, type="response"), 
     EPL09$homeTeamGoals)

## Rootograms (from library(countreg), but not library(vcd)): 
## for Assessing Goodness of Fit of Probability Models:
library(countreg)
countreg::rootogram(EPL09.pois1, max = 9, main = "EPL09: Poisson")

## Some influential plots:
library(car)
influencePlot(EPL09.pois1)
influenceIndexPlot(EPL09.pois1)

## A few "unusual" point:
EPL09[c("27", "126", "311", "373", "358"),]

## Check for over-dispresion:

## A rough measure: X^2/df not much greater than 1.
## It requires one to be confident that the lack-of-fit
## is not due to something else.
sum(residuals(EPL09.pois1, type="pearson")^2) / EPL09.pois1$df.residual

## Test for the null hypothesis of Poisson variation 
## against an alternative that the variance has a particular form
## Var(y) = mu + alpha * mu^ trafo (trafo = 1 or 2)
library(AER)
dispersiontest(EPL09.pois1, 1)
dispersiontest(EPL09.pois1, 2)

## Predict the avearge home goal when the home team is Chelsea, away team is Arsenal:
lam.pred <- predict(EPL09.pois1, data.frame(homeTeam="Chelsea", awayTeam="Arsenal"), type="response")
lam.pred

## Extract information from the fitted parameters:
pois1.params <- data.frame(summary(EPL09.pois1)[12])
colnames(pois1.params) <- c('Estimate','Std.Error','z.val','p.val')

pois1.params[order(pois1.params$Estimate, decreasing=TRUE),]
