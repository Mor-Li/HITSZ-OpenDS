## The data set contains gene expression data (200 genes for 120 samples) 
## and gene expression levels of TRIM32 from the microarray experiments of 
## mammalian eye tissue samples of Scheetz et al. (2006).

library(glmnet)
library(NormalBetaPrime)
data(eyedata, package="NormalBetaPrime") 

str(genes)
str(trim32)

## Ridge, fixed lambda
lam <- 2
ridge.mod2 <- glmnet(genes, trim32, alpha = 0, lambda = lam)

ridge.pred2 <- predict(ridge.mod2, s = 4, newx=genes)
plot(trim32, ridge.pred2)
abline(a=0, b=1)

## Reserve 40 samples for testing:
set.seed(1)
test.sample <- sample(nrow(genes), 40)

# Training data
trainX <- genes[-test.sample, ]
trainY <- trim32[-test.sample]

# Test data
testX <- genes[test.sample, ]
testY <- trim32[test.sample]

## Ridge regression.

## Basic usage:      glmnet(X, y, alpha, ...)
## Cross-validation: cv.glmnet(X, y, alpha, ...)
## Ridge: alpha = 0, LASSO: alpha = 1

set.seed(2)

ridge.cv <- cv.glmnet(trainX, trainY, alpha = 0, 
                      nfolds = 10, type.measure = "mse")

par(cex=1.5)
plot(ridge.cv)
plot(ridge.cv$glmnet.fit, xvar = "lambda")

### Ridge, training and test MSE:

bestlam <- ridge.cv$lambda.1se

ridge.pred.train <- predict(ridge.cv, s = bestlam, newx = trainX)
mean((ridge.pred.train - trainY)^2)

ridge.pred.test <- predict(ridge.cv, s = bestlam, newx = testX)
mean((ridge.pred.test - testY)^2)

plot(testY, ridge.pred.test)
abline(0, 1)

## LASSO regression.

## Basic usage:      glmnet(X, y, alpha, ...)
## Cross-validation: cv.glmnet(X, y, alpha, ...)

## Set alpha = 0 for ridge, alpha = 1 for LASSO

set.seed(2)
lasso.cv <- cv.glmnet(trainX, trainY, alpha = 1, 
                      nfolds = 10, type.measure = "mse")

par(cex=1.5)
plot(lasso.cv)
plot(lasso.cv$glmnet.fit, xvar = "lambda")

## Two methods to extract the coefficients:
lasso.coef <- coef(lasso.cv, s=lasso.cv$lambda.1se) 
lasso.coef.v2  <- predict(lasso.cv, type="coef", 
                          s=lasso.cv$lambda.1se)

## Get the non-zero coefficients:
nz.ind <- which(lasso.coef != 0, arr.ind=TRUE)
cbind( nz.ind, lasso.coef[nz.ind] )

## No. of zero coefficients:
length( which(lasso.coef == 0) )

### LASSO, training and test MSE:

bestlam <- lasso.cv$lambda.1se

pred.train <- predict(lasso.cv, s = bestlam, newx = trainX)
mean((pred.train - trainY)^2)

pred.test <- predict(lasso.cv, s = bestlam, newx = testX)
mean((pred.test - testY)^2)

### LASSO, another way to get training and test MSE.
### A bit different from above, which is due to numerical implementation.

model <- glmnet(trainX, trainY, alpha = 1,
                lambda = bestlam)

mean( (predict(model, newx = trainX) - trainY)^2 )
mean( (predict(model, newx = testX) - testY)^2 )

## Plot test prediction v.s. observation:
par(cex=1.5, pch=19, lwd=2)
plot(testY, pred.test)
abline(0, 1)
