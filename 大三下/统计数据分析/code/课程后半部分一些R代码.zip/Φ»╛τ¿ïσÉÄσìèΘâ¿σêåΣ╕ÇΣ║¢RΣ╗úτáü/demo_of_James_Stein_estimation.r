## Demo of J-S estimator:
set.seed(1)

ntrials = 100
err_MLE = rep(0, ntrials)
err_JSE = rep(0, ntrials)

N = 100         
mu = rnorm(N)   # mu generated from N(0, 1)
# mu = runif(N) # try some other distributions

for (i in 1:ntrials){
    e = rnorm(N, 0, 1)
    x = mu + e
    mu_MLE = x                          ## MLE
    mu_JSE = (1 - (N-2)/sum(x^2))*x     ## J-S
    
    err_MLE[i] = sum((mu_MLE - mu)^2)/N
    err_JSE[i] = sum((mu_JSE - mu)^2)/N
}

err1 = as.data.frame(cbind(err_MLE, err_JSE))

par(cex=1.5, pty="s")
boxplot(err1, ylab = "Error")
