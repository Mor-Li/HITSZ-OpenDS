## Analysis of the titanic data
library(MASS)
library(vcd)
library(vcdExtra)

Titanic.raw <- data.frame( read.csv('./data/Titanic_R.csv',
             header=T, sep=',', na.strings=c(""," ","NA")) )
## Treat empty element as NA.

# pclass:     1 = 1st, 2= 2nd, 3 = 3rd 
# survived:   0 = Died, 1 = Survived
# Residence:  0 = American, 1 = British, 2 = Other
# Name
# age
# sibsp:      Number of siblings/ spouses
# parch:      Number of parents/ children on board
# Ticket:     Ticket number
# fare:       Price of ticket
# Cabin:      Cabin number
# Embarked:   Where passenger embarked
# Boat:       Boat identification (if rescued)
# Body:       Body number (if died)
# Home.dest:  Home town
# Gender:     0 = Male, 1=Female

str(Titanic.raw)

## Missing data issue:
colSums(is.na(Titanic.raw))

library(VIM)
aggr(Titanic.raw)
matrixplot(Titanic.raw)

## Drop some features (personal choice):
Titanic.v2 <- subset(Titanic.raw, 
  select = -c(name, ticket, cabin, boat, body, home.dest, embarked))
colSums(is.na(Titanic.v2))

## Issue of age:
summary(Titanic.v2$age)
hist(Titanic.v2$age)

## There are still a lot of ages missing.
## We can impute the missing ages with mean/medium age by:
# Titanic <- Titanic.v2
# Titanic$age[is.na(Titanic.v2$age)] <- median(Titanic.v2$age, na.rm=T)

## For simplicity, I omit all the rows with missing data.
Titanic <- na.omit(Titanic.v2)
nrow(Titanic)
colSums(is.na(Titanic))

## To tell R which are factors:
Titanic$survived  <- factor(Titanic$survived, c(0,1), labels=c('Died','Survived'))
Titanic$pclass    <- factor(Titanic$pclass, c(1,2,3), labels=c('First','Second','Third'))
Titanic$Residence <- factor(Titanic$Residence, levels=c(0,1,2), labels=c('American','British','Other'))
Titanic$Gender    <- factor(Titanic$Gender, levels=c(0,1), labels=c('Male','Female'))

## Reserve 345 samples for testing:
set.seed(5)
test.sample <- sample.int(nrow(Titanic), 345, replace=F)
Titanic.train <- Titanic[-test.sample, ]
Titanic.test  <- Titanic[test.sample, ]

nrow(Titanic.train)
nrow(Titanic.test)

## Logistic regression for prediction:

## Null model:
TTN.lg0 <- glm(survived=="Survived" ~ 1, 
               data=Titanic.train, family = "binomial")

## Model with all main effects:
TTN.lg.fullLN <- glm(survived=="Survived" ~ ., 
                  data=Titanic.train, family = "binomial")

## Stepwise by AIC:
TTN.lg.AICLN <- stepAIC(TTN.lg.fullLN, 
                        direction="both", trace=FALSE)

summary(TTN.lg.AICLN)

## Effects plots:
library(effects)
plot( allEffects(TTN.lg.AICLN) )

## Full model with all pair-wise interactions:
TTN.lg.fullPW <- glm(survived=="Survived" ~ (.)^2, data=Titanic.train, family = "binomial")

## Step-wise by AIC:
TTN.lg.AICPW <- stepAIC(TTN.lg.fullPW, direction="both", trace=FALSE)

## A simplified demo for cross-validation (see ISLR for more):

library(boot)
## Cross-validation for a few candidates models:
TTN.lg1 <- glm(survived=="Survived" ~ pclass + Gender + age, 
               data=Titanic.train, family = "binomial")
TTN.lg2 <- glm(survived=="Survived" ~ pclass + Gender + Residence, 
               data=Titanic.train, family = "binomial")
TTN.lg3 <- glm(survived=="Survived" ~ pclass * Gender + age, 
               data=Titanic.train, family = "binomial")
model.list = list(TTN.lg1, TTN.lg2, TTN.lg3)

## Define the metric (classification error) for model comparison:
cost <- function(r, pi = 0) mean(abs(r-pi) > 0.5)

set.seed(5)
cv.err = rep(0, 3)
for (i in 1:3){
    model <- model.list[[i]]
    glm.fit <- cv.glm(Titanic.train, model, cost=cost, K=10)
    cv.err[i] <- glm.fit$delta[[1]]
}

cv.err

## Effect plots:
plot( allEffects(TTN.lg3) )

## A personal choice after some explorations:
TTN.lg.ps <- glm(survived=="Survived" ~ pclass * (Gender + age), 
                  data=Titanic.train, family = "binomial")

summary(TTN.lg.ps)

LRstats(TTN.lg0, TTN.lg.AICLN, TTN.lg3, TTN.lg.ps)

## Define a function to compute prediction accuracy:
cal.accuray <- function(model, data){
    pred.prob  <- predict(model, newdata=data, type="response")
    pred.label <- ifelse(pred.prob > 0.5, "Survived", "Died")
    mean(pred.label == data$survived)
}

## Training and test accuraries:
cal.accuray(TTN.lg.ps, Titanic.train)
cal.accuray(TTN.lg.ps, Titanic.test)

## For simple models, the effects are relatively easy to interpret.
plot( allEffects(TTN.lg.ps) )

## Basic diagnostic:
plot(TTN.lg.ps, which=c(4, 5))

## To investigate possible influential point:

library(car)

## Influence plot (residual vs. leverage), 
## showing Cook’s D as the size of the bubble:
influencePlot(TTN.lg.ps)

influenceIndexPlot(TTN.lg.ps)

## Notice the behaviour of indexing for subsetted:
Titanic.train[5,]
Titanic.train["5",]

## Print out some influence data found by influencePlot
## (though not so influential)
Titanic.train[c("94", "107", "384", "635", "757", "1161"),]

## Checking multicollinearity:
library(car)
vif(TTN.lg.ps)
sqrt(5)
sqrt(10)

library(ROCR)

pred.prob <- predict(TTN.lg.ps, newdata=Titanic.test, 
                     type="response")

## Two functions from ROCR:
pred <- prediction(pred.prob, Titanic.test$survived)
perf <- performance(pred, measure = "tpr", x.measure = "fpr")

## ROC curve:
plot(perf, colorize = TRUE, text.adj = c(-0.2, 1.7), 
     print.cutoffs.at = seq(0,1,0.1))

## AUC:
perf.auc <- performance(pred, measure="auc")
perf.auc@y.values[[1]]
