## Load libraries
library(vcd)
library(vcdExtra)
library(fitdistrplus)

## PhD publication data:

# A data frame with 915 observations on the following 6 variables.

# articles
#   number of articles published in the final three years of PhD studies

# female
#   dummy variable for gender, coded 1 for female

# married
#   dummy variable for marital status, coded 1 for married

# kid5
#   number of young children, age 5 and under

# phdprestige
#   prestige of the PhD department. The higher the number the more prestigious the program.

# mentor
#   number of publications by the mentor in the preceeding three years

data("PhdPubs", package = "vcdExtra")
str(PhdPubs)

## No. of articles:
art.tab <- table(PhdPubs$articles)
par(cex=1.5)
barplot(art.tab)

npubs <- as.numeric( names(art.tab) )
art.counts <- rep(npubs, art.tab)

mean(art.counts)
var(art.counts)

## Identify factor variables:
PhdPubs$female  <- factor(PhdPubs$female, levels=c(0, 1), 
                          labels=c("male", "female"))
PhdPubs$married <- factor(PhdPubs$married, levels=c(0, 1), 
                          labels=c("unmarried", "married"))

## Null model:
myfit.phd.poi0 <- glm(articles~1, data=PhdPubs, family="poisson")
myfit.phd.poi0
exp( unname( myfit.phd.poi0$coefficients ) )

## Null model corresponds to fitting all data to a single Poisson:
fitdist(PhdPubs$articles, distr = "pois")

## Fitted to Poisson by goodfit:
plot(goodfit(PhdPubs$articles), xlab = "Number of Articles")

## Fitted to negative binomial by goodfit:
plot(goodfit(PhdPubs$articles, type = "nbinomial"))

## Poisson regressoin using three models, from simple to complex.

## Intercept only:
phd.pois0 <- glm(articles ~ 1, data=PhdPubs, family=poisson)

## All main effects:
phd.pois1 <- glm(articles ~ ., data=PhdPubs, family=poisson)

## All pair-wise interactions:
## (uncommon to include all interactions, just for an illustration)
phd.pois2 <- glm(articles ~ .^2, data=PhdPubs, family=poisson)

phd.pois1

## Compare models by LRstats:
LRstats(phd.pois0, phd.pois1, phd.pois2)

## Compare (nested) models by anova:
anova(phd.pois1, phd.pois2, test="LR")

## Visual summary of effects:
library(effects)
plot(allEffects(phd.pois1))

## Some diagnostic plots:
par(mfrow=c(1,2), cex=1.2,  pty="s")
plot(phd.pois1, which=c(1,5))

## Influential observations:
library(car)
influencePlot(phd.pois1)

## Unusual observations:
PhdPubs[c("328", "803", "913", "914", "915"), ]

## Check for over-dispresion:

## A rough measure:
## needs to be confident that the lack-of-fit is not due to anything else.
sum(residuals(phd.pois1, type="pearson")^2) / phd.pois1$df.residual

## Test for the null hypothesis of Poisson variation 
## against an alternative that the variance has a particular form
## Var(y) = mu + alpha * mu^ trafo (trafo = 1 or 2)

library(AER)
dispersiontest(phd.pois1, 1)  ## f(mu) = mu
dispersiontest(phd.pois1, 2)  ## f(mu) = mu^2

## Fit to negative binomial:
library(MASS)
phd.nbin0 <- glm.nb(articles ~ 1, data=PhdPubs)
phd.nbin1 <- glm.nb(articles ~ ., data=PhdPubs)

summary(phd.nbin1)

## Compare Poisson and negative binomial:
LRstats(phd.pois1, phd.nbin1)

## Some diagnostic plots:
plot(phd.nbin1, which=c(1,3,5))

## Effect plots:
plot(allEffects(phd.nbin1))

## rootogram to visualize goodness-of-fit of models:
# install.packages("countreg", repos="http://R-Forge.R-project.org")
library(countreg)
countreg::rootogram(phd.pois1, max = 12, main = "PhDPubs: Poisson")
countreg::rootogram(phd.nbin1, max = 12, main = "PhDPubs: Negative-Binomial")

## zero-inflated model.

## More parameters are needed in order to predict the zero components.
## Sometimes useful to separately model the zero counts.

library(pscl)
phd.zip1 <- zeroinfl(articles ~ ., data=PhdPubs, dist="poisson")
summary(phd.zip1)

## The "LR Chisq" of phd.pois1 and phd.nbin1 have different values when phd.zip1 is included. (why?)
## (Guess: the package is assuming a Poisson-logit model for all three models when calculting likelihood.)
LRstats(phd.pois1, phd.nbin1, phd.zip1)
