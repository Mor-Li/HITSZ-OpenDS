# library vcd: Visualizing Categorical Data

## Arthritis, a dataset from Koch and Edwards (1988) 
## from a double-blind clinical trial investigating 
## a new treatment for rheumatoid arthritis.

## mosaic plot (lib vcd) for visualizing observed
## assoc plot (lib vcd) for visualizing residual
## corrplot (lib corrplot) for visualizing residual, e.g., corrplot(mytest$residuals, is.cor = FALSE)

library(vcd)
data("Arthritis")
head(Arthritis)

str(Arthritis)

## Some explorations:

## bar chart:
par(mfrow=c(1,2), cex=1.2, pty="s")
barplot(table(Arthritis$Treatment), ylab="Freq")
barplot(table(Arthritis$Improved))

## pie chart:
par(mfrow=c(1,2), cex=1.2, pty="s")
pie(table(Arthritis$Treatment))
pie(table(Arthritis$Improved))

## Use two attributes to create a contingency table:
## (Elements in a contingency table are frequencies of observations)
mytable <- xtabs(~ Treatment + Improved, data = Arthritis)
mytable
addmargins(mytable)

## Express table entries as fractions:
prop.table(mytable)

## clustered bar chart:
par(cex=1.5)
mytable2 <- t(mytable)  ## transpose in order to place row on x-axis
barplot(mytable2, ylab="Frequency", legend=rownames(mytable2), 
        col=c("gray", "lightcyan", "aquamarine"), beside=TRUE)

## Stacked bar chart:
par(cex=1.5)
barplot(mytable2, ylab="Frequency", legend=rownames(mytable2), 
        col=c("gray","lightcyan", "aquamarine"), 
        xlim=c(0, ncol(mytable2)+2)) 

## row-wise percentage (normalized by "Treatment"):
mytable3 <- prop.table(mytable, margin=1)
addmargins(mytable3)

## Stacked bar chart of percentages:
par(cex=1.5)
mytable4 <- t( mytable3 ) 
barplot(mytable4, ylab="Relative frequency", 
        legend=rownames(mytable4), 
        col=c("gray","lightcyan", "aquamarine"), 
        xlim=c(0, ncol(mytable4)+2))

## using mosaic() from vcd:
mosaic(mytable)

## Add features in mosaic:
mosaic(mytable, shade = TRUE, legend = TRUE,  
       gp = shading_max)

## chi-sq test:
mytest <- chisq.test(mytable)
mytest
qchisq(df=(2-1)*(3-1), p=0.95)  # critical value of sig. level 0.05

## If null hypothesis is true, the mosaic plot should look like this:
mosaic(mytest$expected)

## effect size, Cramer's V by hand 
## It lies between 0 and 1, closer to 1 means larger association
nr <- nrow(mytable)
nc <- ncol(mytable)
n  <- sum(mytable)
cv1 <- sqrt( mytest$statistic[[1]] / (n*(min(nr, nc) - 1)) ) 
cv1

## Cramer's V by assocstats in vcd
assocstats(mytable)     

## by the effectsize package
library(effectsize)
cramers_v(mytest)

## comment:
## As for the interpretation for Cramer's V various rules of thumb exist 
## but one of them is from Cohen (1988) who let's the interpretation 
## depend on the degrees of freedom (not in chisq-test, but min(nr, nc)-1.)
## df*  negligible  small         medium        large
## 1    0 < 0.10    0.10 < 0.30   0.30 < 0.50   0.50 or more
## 2    0 < 0.07    0.07 < 0.21   0.21 < 0.35   0.35 or more
## 3    0 < 0.06    0.06 < 0.17   0.17 < 0.29   0.29 or more
## 4    0 < 0.05    0.05 < 0.15   0.15 < 0.25   0.25 or more
## 5    0 < 0.05    0.05 < 0.13   0.13 < 0.22   0.22 or more

## In the association plot, each cell is shown by a rectangle,
## (signed) height ~ Pearson residual, width = sqrt(expected).
assoc(mytable, shade=TRUE, gp = shading_max)
