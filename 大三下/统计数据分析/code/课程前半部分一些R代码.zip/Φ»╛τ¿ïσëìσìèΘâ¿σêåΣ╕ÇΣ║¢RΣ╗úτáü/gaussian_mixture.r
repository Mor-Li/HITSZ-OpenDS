## mclust package:
## Ref: https://cran.r-project.org/web/packages/mclust/vignettes/mclust.html
## Ref: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5096736/

## Method used:
## "Model-based clustering based on parameterized finite Gaussian mixture models. 
##  Models are estimated by EM algorithm initialized by hierarchical model-based agglomerative clustering. 
##  The optimal model is then selected according to BIC."
## The BIC is better for higher value, which is different from the normal convention.

library(mclust)

## Artificial 1D data:
par(cex=1.5)
set.seed(5)
x1 <- rnorm(1000, mean=0, sd=2.0)  
x2 <- rnorm(500, mean=9, sd=1.5)  
x3 <- rnorm(300, mean=13, sd=1.0)  
x <- c(x1, x2, x3)
hist(x, breaks=30)

## Fitting to Artificial 1D data by Mlust:
par(cex=1.5)
mytest <- Mclust(x)
summary(mytest)
plot(mytest, what="density", data=x, breaks=30)

## BIC for different gaussian mixture models, 
## "E": equal-variance, "V": variable/unqual variance
par(cex=1.5)
plot(mytest, what="BIC")

## Extract results:
names(mytest)
# mytest$classification  ## to get the class membership
mytest$parameters  ## to access the estimated parameters

## Plot class membership found by mclust:
par(cex=1.5)
plot(mytest, what="classification")

## Make prediction on a new point:
predict(mytest, 11.2)
predict(mytest, 11.3)

## Artificial 2D data on a ring:
set.seed(2)
theta <- 2*pi*runif(100)
x.toy <- 2*sin(theta) + rnorm(100)*0.1
y.toy <- cos(theta) + rnorm(100)*0.1

data.toy <- cbind(x.toy, y.toy)
plot(data.toy)

## Fitting to Artificial 2D data and visualization:
mytest.toy <- Mclust(data.toy)
# summary(mytest.toy)
plot(mytest.toy, what="density")

## Non-parametric:
library(spatstat)
window <- owin(c(-3, 3), c(-3, 3))
ppp.toy <- ppp(x=x.toy, y=y.toy, window)
density.toy <- density(ppp.toy, adjust=0.4)
contour(density.toy)

## diabete dataset in mclust ----
## The data set contains three measurements made on 145 non-obese adult patients classified into three groups.
# class:    The type of diabete: Normal, Overt, and Chemical.
# glucose:  Area under plasma glucose curve after a three hour oral glucose tolerance test (OGTT).
# insulin:  Area under plasma insulin curve after a three hour oral glucose tolerance test (OGTT).
# sspg:     Steady state plasma glucose.
data(diabetes)
head(diabetes)

summary(diabetes)

## Consider 2 features: glucose and insulin
par(cex=1.5)
diabetes.2D <- diabetes[, 2:3]     ## 2D data
plot(diabetes.2D)

## Fitting to the 2-featured diabete data:
par(cex=1.5)
mytest.diabetes.2D <- Mclust(diabetes.2D)
plot(mytest.diabetes.2D, what="BIC")

## Result of the fitting and visualization:
par(cex=1.5)
mytest.diabetes.2D
summary(mytest.diabetes.2D)
plot(mytest.diabetes.2D, what="classification")

## Consider all 3 features: glucose, insulin and sspg:
par(cex=1.5)
diabetes.3D <- diabetes[,2:4]     ## 3D data
pairs(diabetes.3D)

## Fitting to the 3-featured diabete data, and visulization:
mytest.diabetes.3D <- Mclust(diabetes.3D)
# summary(mytest.diabetes.3D)
plot(mytest.diabetes.3D, what="classification")

## Propotion of different class:
round( prop.table( table(diabetes[ ,1]) ), digit=3 )  ## data
round( mytest.diabetes.3D$parameters$pro, digit=3 )   ## GMM

## To compute "classification accurary".
## Note that we can not know the true labels from Gaussian mixture (as they are hidden/latent),
## we need some extra knowledge to identify which class is "Normal", which class is "Chemical", etc.

## Here we manually identify the correct order of classes, 
## by noticing "Normal" has the largest propotion, 
## and "Chemical" has the second largest propotion.
lvs <- c("Normal", "Chemical", "Overt")  
diabetes.class.by.GMM <- lvs[ mytest.diabetes.3D$classification ]

length(diabetes[ ,1])  ## no. of instance
sum( diabetes.class.by.GMM == diabetes[ ,1])   ## no. of correctly classified
mean( diabetes.class.by.GMM == diabetes[ ,1])  ## accurary
