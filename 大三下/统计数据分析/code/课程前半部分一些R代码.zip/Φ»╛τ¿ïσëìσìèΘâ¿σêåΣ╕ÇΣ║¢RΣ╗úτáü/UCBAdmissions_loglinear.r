library(vcd)
library(vcdExtra)
library(MASS)

## UCBAdmissions data:
## Aggregate data on applicants to graduate school at Berkeley 
## for the six largest departments in 1973 classified by admission and sex.
library(vcd)
data("UCBAdmissions")
str(UCBAdmissions)

## Place Gender in X dimension:
UCBAdmissions <- aperm(UCBAdmissions, c(2,1,3))
str(UCBAdmissions)

## View the table:
# UCBAdmissions

## For a better view, flatten the contingency tables.
UCB.ft <- ftable(UCBAdmissions)
UCB.ft
addmargins(UCB.ft)

## Consider the margin table of Gender and Admit:
UCB.GA <- margin.table(UCBAdmissions, 
                       margin=c(1,2))
addmargins(UCB.GA)

## The margin table in proportion of each gender:
UCB.GA.mg1 <- prop.table(UCB.GA, margin=1)
round(addmargins( UCB.GA.mg1 ), 2)

## bar chart of the propotional margin table:
par(cex=1.5)
barplot(t(UCB.GA.mg1), horiz=TRUE, legend=colnames(UCB.GA.mg1))

## Chi-squared test of independence:
chisq.test(UCB.GA)

## Association Statistics:
assocstats(UCB.GA)

## Odds ratio and confidence interval by library(vcd):
oddsratio(UCB.GA, log=FALSE)           ## odds ratio
confint(oddsratio(UCB.GA, log=FALSE))  ## confidence interval

## Odds ratio by hand:
OR.UCB.GA <- UCB.GA[1,1]*UCB.GA[2,2]/(UCB.GA[1,2]*UCB.GA[2,1])
OR.UCB.GA

## Confidence interval of odds ratio by hand:
OR.lw <- log(OR.UCB.GA) - sqrt(sum(1/UCB.GA)) * qnorm(0.975)
OR.up <- log(OR.UCB.GA) + sqrt(sum(1/UCB.GA)) * qnorm(0.975)
exp(OR.lw)
exp(OR.up)

## odds ratio for each department with confidence interval:
plot(oddsratio(UCBAdmissions, log=FALSE), 
     xlab="Department")

## A matrix of (marginal) mosaic plots for the 3-way contingency tables:
pairs(UCBAdmissions, gp=shading_max)

## Conditional plots for the 3-way contingency tables:
cotabplot(UCBAdmissions, cond="Dept")

## Doubledecker plot.
## Formally, they are mosaic plots with vertical splits: 
doubledecker(Admit ~ Dept + Gender, 
             data = UCBAdmissions, 
             gp=gpar(fill=c("aquamarine", "gray")))

## Log-linear model approach:

## Complete Independence:
## [A][D][G]
UCB.loglm0 <- loglm(~ Dept + Gender + Admit, data = UCBAdmissions, 
                    param = TRUE, fitted = TRUE)
UCB.loglm0

## Joint Independence:
## [A][DG]
UCB.loglm1 <- loglm(~ Dept * Gender + Admit, data = UCBAdmissions,
                     param = TRUE, fitted = TRUE)

## [AG][D]
UCB.loglm2 <- loglm(~ Dept + Admit * Gender, data = UCBAdmissions,
                     param = TRUE, fitted = TRUE)

## [AD][G]
UCB.loglm3 <- loglm(~ Dept * Admit + Gender, data = UCBAdmissions,
                     param = TRUE, fitted = TRUE)

## Conditional Independence:
## [AD][AG]
UCB.loglm4 <- loglm(~ Admit*(Dept + Gender), data = UCBAdmissions,
                     param = TRUE, fitted = TRUE)

## [DA][DG]
UCB.loglm5 <- loglm(~ Dept*(Admit + Gender), data = UCBAdmissions,
                     param = TRUE, fitted = TRUE)

## [GA][GD]
UCB.loglm6 <- loglm(~ Gender*(Admit + Dept), data = UCBAdmissions,
                     param = TRUE, fitted = TRUE)

## Homogeneous Association:
## [GA][GD][AD]
UCB.loglm7 <- loglm(~ (Gender + Admit + Dept)^2, data = UCBAdmissions,
                     param = TRUE, fitted = TRUE)

## Brief Summary of model fit by LRstats() from library(vcdExtra):
LRstats(UCB.loglm0, 
        UCB.loglm1, UCB.loglm2, UCB.loglm3, 
        UCB.loglm4, UCB.loglm5, UCB.loglm6, 
        UCB.loglm7)

## Use anova() for model comparison:
## (the name anova mostly comes from linear regression,
## for GLM, it is more like "analysis of deviance".)

## The hypothesis testing is only meaningful when the models are nested,
## that is, the 1st model is the special case of the 2nd, etc.

## Here we want to compare UCB.loglm5 and UCB.loglm7:
anova(UCB.loglm5, UCB.loglm7, test="LR")  ## OR test="Chisq"

## Results interpretation :
## 1st test: H0: UCB.loglm5, H1: UCB.loglm7 -> p-val = 0.2159
## 2nd test: H0: UCB.loglm7, H1: saturated  -> p-val = 0.0011

## Visually compare Pearson residuals 
mosaic(UCB.loglm5)  ## [DA][DG], or A⊥G | D  ## Female on Dept A is not well fitted

## To extract residuals:
# residuals(UCB.loglm5, type="pearson")

## To extract parameters:
# UCB.loglm5$param

## Compare odds of fitted to odds of observed:

## model 5: log(odds(Being admitted)):
odds.fitted.loglm5 <- log( UCB.loglm5$fitted[,1,] / UCB.loglm5$fitted[,2,] )
odds.fitted.loglm5

## observed: log(odds(Being admitted)):
odds.obs <- log(UCBAdmissions[,1,] / UCBAdmissions[,2,])
odds.obs
