library(MASS)
library(vcd)
library(vcdExtra)

## Educational Aspirations in Wisconsin
mydata <- c(749,35,233,133, 
            627,38,330,303, 
            420,37,374,467, 
            153,26,266,800)

var.levels <- expand.grid(Plan = c("No", "Yes"),
                    Encouragement = c("Low", "High"),
                    SES = c("Lower", "Lower_Middle", 
                            "Upper_Middle", "Higher"))

Wis.freq <- data.frame(var.levels, count = mydata)

Wis.tab <- xtabs(count ~ Encouragement + Plan + SES, 
                 data = Wis.freq)

pairs(Wis.tab, gp=shading_max)

cotabplot(Wis.tab, cond="SES")

doubledecker(Plan ~ SES + Encouragement, data = Wis.tab)

## convert table to dataframe for glm():
Wis.df <- as.data.frame(Wis.tab)

## Complete Independence:
## [E][P][S]
Wis.glm0 <- glm(Freq ~ Encouragement + Plan + SES,
                data = Wis.df, family = "poisson")
Wis.glm0

## Joint Independence:
## [EP][S]
Wis.glm1 <- glm(Freq ~ Encouragement * Plan + SES,
                data = Wis.df, family = "poisson")

## [E][PS]
Wis.glm2 <- glm(Freq ~ Encouragement + Plan * SES,
                data = Wis.df, family = "poisson")

## [P][ES]
Wis.glm3 <- glm(Freq ~ Plan + Encouragement * SES,
                data = Wis.df, family = "poisson")

## Conditional Independence:
## [EP][ES]
Wis.glm4 <- glm(Freq ~ Encouragement * (Plan + SES),
                data = Wis.df, family = "poisson")

## [SE][SP]
Wis.glm5 <- glm(Freq ~ SES * (Encouragement + Plan),
                data = Wis.df, family = "poisson")

## [PE][PS]
Wis.glm6 <- glm(Freq ~ Plan * (Encouragement + SES),
                data = Wis.df, family = "poisson")

## Homogeneous Association:
## [ES][PE][PS]
Wis.glm7 <- glm(Freq ~ (Plan + Encouragement + SES)^2,
                data = Wis.df, family = "poisson")

## Compare all models:
LRstats(Wis.glm0,
        Wis.glm1, Wis.glm2, Wis.glm3,
        Wis.glm4, Wis.glm5, Wis.glm6,
        Wis.glm7)

## Homogeneous association:
## We conclude that we have no evidence against the hypothesis that all three variables are associated, 
## but the association between any two is the same at all levels of the third. 
## In particular, we may conclude that the association between 
## parental encouragement E and college plans P is the same in all social strata.

plot(oddsratio(Wis.tab, log=FALSE))

## Test for Homogeneity of Odds Ratios:
library(DescTools)
woolf_test(Wis.tab)      ## library(vcd)
BreslowDayTest(Wis.tab)  ## library(DescTools), only work for 2x2xk

## CMH test for conditional independence.
## assumption: there is no three-way interaction.
mantelhaen.test(Wis.tab)

## Show Pearson residuals on mosaic plot:
mosaic(Wis.glm7)  ## [ES][PE][PS]

## Extract residuals and plot:
pearson.residual.glm7 <- residuals(Wis.glm7, type="pearson")
standard.residual.glm7 <- rstandard(Wis.glm7)

par(mfrow=c(1,2), pch=19, pty="s")
plot( pearson.residual.glm7 )
plot( standard.residual.glm7 )

## Equivalent Logit model of homogeneous association ([ES][PE][PS]):
Wis.glm7.lg <- glm(Plan=="Yes" ~ Encouragement + SES, 
                   data = Wis.df, weights = Freq, 
                   family = "binomial")
Wis.glm7.lg

## The logit model is easier to interpret.
## Effect plots for the Equivalent Logit model:
library(effects)
plot( allEffects(Wis.glm7.lg) )
