## Demo of fitdistrplus on normal data:
library(fitdistrplus)

set.seed(1)
myfit.norm <- fitdist(rnorm(1000), "norm", method="mle")
summary(myfit.norm)

## Parametric boostrap:
myfit.norm.boot <- bootdist(myfit.norm, bootmethod="param", niter=1000)
summary(myfit.norm.boot)

## Plot bootstrapped:
plot(myfit.norm.boot, trueval=myfit.norm$estimate)

## Extract bootstrapped estimations:
boot.estim <- myfit.norm.boot$estim
head(boot.estim)

## Fitting to binomial distribution, when size is known as 6:
myfit.binom <- fitdist(data=c(2,3,4,2,3), dist="binom", 
                       fix.arg=list(size=6), start=list(prob=0.3))
summary(myfit.binom)

## Fitting to user-defined distribution with fitdistrplus needs some extra efforts.
## A demo:
## mydistr(x|mu) = N(x|mean=mu, sd=5)

library(fitdistrplus)

dmydistr <- function(x, mu) dnorm(x, mean=mu, sd=5)
pmydistr <- function(q, mu) pnorm(q, mean=mu, sd=5)
qmydistr <- function(p, mu) qnorm(p, mean=mu, sd=5)

set.seed(1)
x <- rnorm(1000, mean=2, sd=5)

## Using fitdistrplus for user-defined distribution with MLE method:
myfit.mle <- fitdist(x, "mydistr", start = list(mu = 1), method="mle")
myfit.mle

## Using fitdistrplus for user-defined distribution with MME method:

## Need to provide the empirical moment, theoretical moment,
## and which order of moment to match:

## Empirical moment：
memp <- function(x, order) sum(x^order)/length(x)      

## Theoretical moments (I only provide first two...):
mmydistr <- function(order, mu){
    if (order == 1){mom = mu}
    else if (order == 2){mom = mu^2+25}
    else {mom = NA}
    return(mom)
}

## to tell fitdist to match the 1st order moment
order <- c(1)   

myfit.mme <- fitdist(x, "mydistr", order=order, memp=memp, 
                     start = list(mu = 1), method="mme")
myfit.mme

## Fitting to rayleigh distribution (defined in extraDistr):
library(fitdistrplus)
library(extraDistr)

## A look at the rayleigh density:
# x.grid <- seq(0, 10, 0.1)
# sigma <- 2
# y.grid <- drayleigh(x.grid, sigma=sigma)
# plot(x.grid, y.grid)
# lines(x.grid, x.grid/sigma^2 * exp(-x.grid^2/(2*sigma^2)))

## Fitting rayleigh of extraDistr:
memp <- function(x, order) sum(x^order)/length(x)
mrayleigh <- function(order, sigma) sigma*sqrt(pi/2)

set.seed(1)
dat <- rrayleigh(100, sigma=2)

rayleigh.mle <- fitdist(dat, "rayleigh", start = list(sigma = 5), method="mle")
rayleigh.mle

rayleigh.mme <- fitdist(dat, "rayleigh", order=c(1), memp=memp, start = list(sigma = 1), method="mme")
rayleigh.mme
