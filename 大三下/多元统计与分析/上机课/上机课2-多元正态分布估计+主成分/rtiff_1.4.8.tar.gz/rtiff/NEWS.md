# rtiff 1.4.6.9000

* Current devel version, no changes yet

# rtiff 1.4.6

* Added a `NEWS.md` file to track changes to the package.
* Changes configure.in to configure.ac
* Registers native routines
