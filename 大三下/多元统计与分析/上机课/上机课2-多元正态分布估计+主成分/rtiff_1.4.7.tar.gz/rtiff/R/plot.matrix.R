"plot.matrix" <-
function (x, ...) {
  plot(newPixmapRGB(x, x, x), ...)
}

